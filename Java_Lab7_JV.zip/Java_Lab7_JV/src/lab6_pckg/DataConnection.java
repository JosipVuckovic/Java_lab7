package lab6_pckg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class DataConnection {
	public List<String> svePoruke()
	{  
		List<String> messages = new ArrayList<String>();
		try{  
			Class.forName("org.postgresql.Driver");
			UserConfig.loadParams();
			String url = "jdbc:postgresql://"+UserConfig.getHost()+":"+UserConfig.getPort()+"/testDB?user=postgres&password=123456";		
			Connection con=DriverManager.getConnection(url);  
		Statement stmt = con.createStatement();  
		ResultSet rs = stmt.executeQuery("select * from data");
		
		while(rs.next()) { 
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
			messages.add(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
		}
		con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return messages;
	}
	
	public void snimiPoruku(String user, String text)
	{
		try{  
			Class.forName("org.postgresql.Driver");
			UserConfig.loadParams();
			String url = "jdbc:postgresql://"+UserConfig.getHost()+":"+UserConfig.getPort()+"/testDB?user=postgres&password=123456";		
			Connection con=DriverManager.getConnection(url);  
			text = text.replace("\u0000", "");
		
			PreparedStatement stmt = con.prepareStatement("insert into data (username, messagetext) values(?,?)");
			stmt.setString(1, user);
			stmt.setString(2, text);
			stmt.execute();		
			
			con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}